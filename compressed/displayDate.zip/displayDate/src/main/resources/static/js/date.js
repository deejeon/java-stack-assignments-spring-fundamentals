window.confirm("This is the date template");
