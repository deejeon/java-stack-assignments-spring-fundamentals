package com.danieljeon.ninjagold.controllers;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MainController {
	
	@RequestMapping("/Gold")
	public String index(HttpSession session) {
		if (session.getAttribute("goldCount") == null) {
			session.setAttribute("goldCount", 0);
			List<Map<String, String>> activities = new ArrayList<>();
			session.setAttribute("activities", activities);
		}
		return "index.jsp";
	}
	
	@RequestMapping(value = "/processMoney", method = RequestMethod.POST)
	public String processMoney(HttpSession session, @RequestParam("name") String name) {
		Random r = new Random();
		int amountFarm = r.nextInt(11) + 10;
		int amountCave = r.nextInt(6) + 5;
		int amountHouse = r.nextInt(4) + 2;
		double negative = Math.pow(-1, r.nextInt(2));
		int neg = (int) negative;
		int amountCasino = r.nextInt(51) * neg;
		int goldCount = (int) session.getAttribute("goldCount");
		List<Map<String, String>> activities = (List<Map<String, String>>) session.getAttribute("activities");
				
		if (name.equals("farm")) {
			session.setAttribute("goldCount", goldCount + amountFarm);
			Date now = new Date();
			String timestamp = now.toString();
			Map<String, String> activity = new HashMap<>();
			activity.put("message", "You entered a farm and earned " + amountFarm +" gold. (" + timestamp + ")");
			activity.put("sign", "positive");
			activities.add(activity);
			session.setAttribute("activities", activities);
		}
		
		else if (name.equals("cave")) {
			session.setAttribute("goldCount", goldCount + amountCave);
			Date now = new Date();
			String timestamp = now.toString();
			Map<String, String> activity = new HashMap<>();
			activity.put("message", "You entered a cave and earned " + amountCave +" gold. (" + timestamp + ")");
			activity.put("sign", "positive");
			activities.add(activity);
			session.setAttribute("activities", activities);
		}
		
		else if (name.equals("house")) {
			session.setAttribute("goldCount", goldCount + amountHouse);
			Date now = new Date();
			String timestamp = now.toString();
			Map<String, String> activity = new HashMap<>();
			activity.put("message", "You entered a house and earned " + amountHouse +" gold. (" + timestamp + ")");
			activity.put("sign", "positive");
			activities.add(activity);			
			session.setAttribute("activities", activities);
		}
		
		else if (name.equals("casino")) {
			session.setAttribute("goldCount", goldCount + amountCasino);
			Date now = new Date();
			String timestamp = now.toString();
			if (amountCasino < 0) {
				Map<String, String> activity = new HashMap<>();
				activity.put("message", "You entered a casino and lost " + amountCasino*(-1) +" gold. Ouch bro! (" + timestamp + ")");
				activity.put("sign", "negative");
				activities.add(activity);
			}
			else {
				Map<String, String> activity = new HashMap<>();
				activity.put("message", "You entered a casino and earned " + amountCasino +" gold. (" + timestamp + ")");
				activity.put("sign", "positive");
				activities.add(activity);
			}
			session.setAttribute("activities", activities);
		}
		
		return "redirect:/Gold";
	}
}
